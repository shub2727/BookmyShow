package com.example.BookMyShow_Showtime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowShowtimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
