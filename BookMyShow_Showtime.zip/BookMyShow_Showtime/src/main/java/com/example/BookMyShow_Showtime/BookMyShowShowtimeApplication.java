package com.example.BookMyShow_Showtime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyShowShowtimeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyShowShowtimeApplication.class, args);
	}

}
