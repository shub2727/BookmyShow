package com.BookMyShow_ServiceRegistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowServiceRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
