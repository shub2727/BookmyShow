package com.example.BookByShow_Ticket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookByShowTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
