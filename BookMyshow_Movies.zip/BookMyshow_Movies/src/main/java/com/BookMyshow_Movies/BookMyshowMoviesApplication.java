package com.BookMyshow_Movies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyshowMoviesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyshowMoviesApplication.class, args);
	}

}
