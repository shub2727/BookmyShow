package com.BookMyshow_Movies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyshowMoviesApplicationTests {

	@Test
	void contextLoads() {
	}

}
