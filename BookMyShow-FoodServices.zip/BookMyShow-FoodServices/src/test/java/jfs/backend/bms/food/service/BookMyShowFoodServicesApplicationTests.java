package jfs.backend.bms.food.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowFoodServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
