package com.example.BookByShow_Payment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookByShowPaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookByShowPaymentApplication.class, args);
	}

}
