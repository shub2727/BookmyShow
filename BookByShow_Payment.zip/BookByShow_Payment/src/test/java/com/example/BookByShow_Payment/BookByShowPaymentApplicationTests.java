package com.example.BookByShow_Payment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookByShowPaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
