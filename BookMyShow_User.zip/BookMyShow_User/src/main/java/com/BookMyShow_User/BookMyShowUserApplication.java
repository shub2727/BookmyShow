package com.BookMyShow_User;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyShowUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyShowUserApplication.class, args);
	}

}
