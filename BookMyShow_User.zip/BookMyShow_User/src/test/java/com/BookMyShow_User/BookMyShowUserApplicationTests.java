package com.BookMyShow_User;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
