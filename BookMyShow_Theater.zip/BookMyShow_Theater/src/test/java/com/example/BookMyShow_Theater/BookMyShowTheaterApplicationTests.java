package com.example.BookMyShow_Theater;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowTheaterApplicationTests {

	@Test
	void contextLoads() {
	}

}
