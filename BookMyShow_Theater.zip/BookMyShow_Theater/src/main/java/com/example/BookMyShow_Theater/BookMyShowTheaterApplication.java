package com.example.BookMyShow_Theater;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyShowTheaterApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyShowTheaterApplication.class, args);
	}

}
