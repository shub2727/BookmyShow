package com.example.BookMyShow_Booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
