package com.example.BookMyShow_Booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyShowBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyShowBookingApplication.class, args);
	}

}
